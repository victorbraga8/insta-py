import os
from dotenv import load_dotenv
from utils.driver import criar_driver
from utils.login import realizar_login
from utils.execute_hashtags import executar_por_hashtags

if __name__ == "__main__":
    load_dotenv()
    user = os.getenv("IG_USER", "")
    pwd = os.getenv("IG_PASS", "")
    hashtags = ["colombia", "argentina", "paraguai"]
    driver = criar_driver(headless=False)
    if user and pwd:
        realizar_login(driver, user, pwd)
    executar_por_hashtags(driver, hashtags, limite_por_tag=30)
    driver.quit()
