from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    ElementClickInterceptedException,
)

LOGIN_URL = "https://www.instagram.com/accounts/login/?next=/"


def _click(driver, el):
    try:
        el.click()
    except ElementClickInterceptedException:
        driver.execute_script("arguments[0].click();", el)


def _dismiss(driver):
    for xp in [
        "//button[.='Aceitar' or .='Allow all' or .='Accept' or .='Permitir todos']",
        "//button[.='Only allow essential' or .='Apenas essenciais']",
        "//div[@role='dialog']//button[.='Agora não' or .='Not now']",
    ]:
        try:
            btn = WebDriverWait(driver, 2).until(
                EC.element_to_be_clickable((By.XPATH, xp))
            )
            _click(driver, btn)
            sleep(0.5)
        except Exception:
            pass


def _already_logged(driver):
    try:
        WebDriverWait(driver, 4).until(
            EC.presence_of_element_located(
                (
                    By.XPATH,
                    "//nav//a[contains(@href,'/explore/')] | //a[contains(@href,'/accounts/edit')]",
                )
            )
        )
        return True
    except TimeoutException:
        return False


def _type_safe(driver, el, text):
    try:
        driver.execute_script(
            "arguments[0].focus(); arguments[0].value=''; arguments[0].dispatchEvent(new Event('input',{bubbles:true}));",
            el,
        )
        driver.execute_script(
            "arguments[0].value=arguments[1]; arguments[0].dispatchEvent(new Event('input',{bubbles:true}));",
            el,
            text,
        )
    except Exception:
        el.clear()
        ActionChains(driver).move_to_element(el).click().send_keys(text).perform()


def realizar_login(driver, username: str, password: str, timeout: int = 30) -> bool:
    driver.get(LOGIN_URL)
    WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((By.TAG_NAME, "body"))
    )
    _dismiss(driver)
    if _already_logged(driver):
        return True

    tries = 3
    for _ in range(tries):
        _dismiss(driver)
        if _already_logged(driver):
            return True

        locs_user = [
            (By.CSS_SELECTOR, "input[name='username']"),
            (By.XPATH, "//input[@name='username']"),
            (
                By.XPATH,
                "//input[@aria-label='Telefone, nome de usuário ou email' or @aria-label='Phone number, username, or email']",
            ),
        ]
        locs_pass = [
            (By.CSS_SELECTOR, "input[name='password']"),
            (By.XPATH, "//input[@name='password']"),
            (By.XPATH, "//input[@aria-label='Senha' or @aria-label='Password']"),
        ]

        user_el = None
        pass_el = None
        last = None
        for by, sel in locs_user:
            try:
                user_el = WebDriverWait(driver, 8).until(
                    EC.presence_of_element_located((by, sel))
                )
                break
            except Exception as e:
                last = e
        for by, sel in locs_pass:
            try:
                pass_el = WebDriverWait(driver, 8).until(
                    EC.presence_of_element_located((by, sel))
                )
                break
            except Exception as e:
                last = e

        if not user_el or not pass_el:
            driver.get(LOGIN_URL)
            continue

        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", user_el)
        ActionChains(driver).move_to_element(user_el).pause(0.1).click().perform()
        _type_safe(driver, user_el, username)

        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", pass_el)
        ActionChains(driver).move_to_element(pass_el).pause(0.1).click().perform()
        _type_safe(driver, pass_el, password)

        try:
            btn = WebDriverWait(driver, 6).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']"))
            )
            _click(driver, btn)
        except Exception:
            driver.execute_script(
                "document.querySelector(\"button[type='submit']\")?.click();"
            )

        try:
            WebDriverWait(driver, 12).until(
                EC.presence_of_element_located(
                    (
                        By.XPATH,
                        "//nav//a[contains(@href,'/explore/')] | //a[contains(@href,'/accounts/edit')]",
                    )
                )
            )
            _dismiss(driver)
            return True
        except TimeoutException:
            driver.get(LOGIN_URL)

    return False
