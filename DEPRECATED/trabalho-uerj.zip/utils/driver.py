from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import os
def criar_driver(headless: bool = False, profile_dir: str = "profile_ig"):
    os.makedirs(profile_dir, exist_ok=True)
    opts = Options()
    if headless:
        opts.add_argument("--headless=new")
    opts.add_argument(f"--user-data-dir={os.path.abspath(profile_dir)}")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--start-maximized")
    opts.add_argument("--window-size=1366,900")
    opts.add_argument("--lang=pt-BR")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    prefs = {"profile.default_content_setting_values.geolocation": 1}
    opts.add_experimental_option("prefs", prefs)
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=opts)
    driver.implicitly_wait(0)
    # geoloc São Gonçalo
    try:
        driver.execute_cdp_cmd("Browser.grantPermissions", {"origin": "https://www.instagram.com", "permissions": ["geolocation"]})
        driver.execute_cdp_cmd("Emulation.setGeolocationOverride", {"latitude": -22.8268, "longitude": -43.0634, "accuracy": 120})
    except Exception:
        pass
    return driver
